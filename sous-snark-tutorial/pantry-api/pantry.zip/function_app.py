"""
Sous Snark Pantry API — tiny Entra-protected backend for the agent demo.

Two endpoints:
  GET  /api/pantry        -> current inventory
  POST /api/pantry/cook   -> log a dish the agent decided to cook

The whole app is gated by Easy Auth (Entra ID, audience-only check).
At the function level we use ANONYMOUS so Easy Auth controls auth, not a function key.
"""
import json
import logging
from typing import List, Dict

import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

PANTRY: List[Dict] = [
    {"name": "eggs", "qty": 4, "unit": "count"},
    {"name": "stale baguette", "qty": 0.5, "unit": "loaf"},
    {"name": "butter", "qty": 120, "unit": "g"},
    {"name": "shallots", "qty": 2, "unit": "count"},
    {"name": "harissa paste", "qty": 1, "unit": "tbsp"},
    {"name": "canned tomatoes", "qty": 400, "unit": "g"},
    {"name": "feta", "qty": 80, "unit": "g"},
    {"name": "cumin", "qty": 1, "unit": "tsp"},
    {"name": "olive oil", "qty": 250, "unit": "ml"},
    {"name": "garlic", "qty": 6, "unit": "cloves"},
]

# In-memory log (resets on cold start — fine for a demo)
_cook_log: List[Dict] = []


def _caller(req: func.HttpRequest) -> str:
    """Easy Auth injects the caller's object id into this header on every authenticated request."""
    return req.headers.get("X-MS-CLIENT-PRINCIPAL-ID", "unknown")


@app.route(route="pantry", methods=["GET"])
def get_pantry(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("get_pantry called by principal=%s", _caller(req))
    return func.HttpResponse(
        json.dumps({"ingredients": PANTRY}),
        status_code=200,
        mimetype="application/json",
    )


@app.route(route="pantry/cook", methods=["POST"])
def post_cook(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            json.dumps({"error": "Body must be JSON"}),
            status_code=400,
            mimetype="application/json",
        )

    dish = (body or {}).get("dish")
    used = (body or {}).get("ingredients_used", [])
    if not dish:
        return func.HttpResponse(
            json.dumps({"error": "'dish' is required"}),
            status_code=400,
            mimetype="application/json",
        )

    entry = {
        "dish": dish,
        "ingredients_used": used,
        "logged_by_principal": _caller(req),
    }
    _cook_log.append(entry)
    logging.info("Cook logged: %s", entry)

    return func.HttpResponse(
        json.dumps({"ok": True, "logged": entry, "total_dishes_logged": len(_cook_log)}),
        status_code=200,
        mimetype="application/json",
    )
